const mongostring = 'mongodb+srv://jeh4253:Chompy234@cluster0.v1gbq.mongodb.net/nrtmsrts';

const getMongoString = () => mongostring;

module.exports.getMongoString = getMongoString;
